import database file 'rosscoscoffee.sql' first.


Username: admin
Password: password
